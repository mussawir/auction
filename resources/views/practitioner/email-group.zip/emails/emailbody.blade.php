<?php
  echo $messagebody;
?>